import React from "react";

const Sample = () => {
  return <div>{import.meta.env.VITE_SAMPLE}</div>;
};

export default Sample;
